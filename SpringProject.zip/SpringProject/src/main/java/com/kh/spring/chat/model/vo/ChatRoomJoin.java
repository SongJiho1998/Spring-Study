package com.kh.spring.chat.model.vo;

import lombok.Data;

@Data
public class ChatRoomJoin {

	private int userNo;
	private int chatRoomNo;
	
}
