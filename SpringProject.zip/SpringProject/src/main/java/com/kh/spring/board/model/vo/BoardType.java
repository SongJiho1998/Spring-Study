package com.kh.spring.board.model.vo;

import lombok.Data;

@Data
public class BoardType {
	
	private String boardCd;
	private String boardName;

}
