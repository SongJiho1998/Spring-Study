package com.kh.spring.board.model.vo;

import java.sql.Date;
import java.util.ArrayList;

import lombok.Data;

@Data
public class Board {
	
	private int boardNo;
	private String boardTitle;
	private String boardContent;
	private String boardWriter;
	private int count;
	private Date CreateDate;
	private String status;
	
	private String originName; // ORIGIN_NAME VARCHAR2(100BYTE)
	private String changeName; // CHANGE_NAME VARCHAR2(100BYTE)
	private String boardCd;
	
	private ArrayList<BoardImg> imgList;

}
